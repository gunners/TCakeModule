<?php
include ("../../inc/define.php");
include (HOST.CONF);
include (HOST.FUNC);
thn_ajaran();
?>
