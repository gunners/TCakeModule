<?php
include ("../../inc/define.php");
include (HOST.CONF);
include (HOST.FUNC);
echo ("GANJIL\nGENAP");
?>
