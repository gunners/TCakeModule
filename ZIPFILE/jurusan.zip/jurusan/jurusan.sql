
CREATE TABLE IF NOT EXISTS `jurusan` (
  `kd_jurusan` varchar(10) NOT NULL,
  `jurusan` varchar(50) NOT NULL,
  PRIMARY KEY  (`kd_jurusan`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

