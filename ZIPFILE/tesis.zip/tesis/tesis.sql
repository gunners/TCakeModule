
CREATE TABLE IF NOT EXISTS `tesis` (
  `id_tesis` int(255) NOT NULL auto_increment,
  `nim` varchar(20) NOT NULL,
  `judul` varchar(500) NOT NULL,
  PRIMARY KEY  (`id_tesis`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

