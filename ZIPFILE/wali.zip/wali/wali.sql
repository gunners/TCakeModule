

CREATE TABLE IF NOT EXISTS `wali` (
  `id_wali` int(255) NOT NULL auto_increment,
  `nip` varchar(50) NOT NULL,
  `nim` varchar(20) NOT NULL,
  PRIMARY KEY  (`id_wali`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;
